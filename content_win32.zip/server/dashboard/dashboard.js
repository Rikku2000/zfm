const tableBody    = document.querySelector("#usersTable tbody");
const serverTimeEl = document.getElementById("serverTime");
const statusMsgEl  = document.getElementById("statusMsg");
const weatherTgEl = document.getElementById("weatherTg");

async function fetchStatus() {
  try {
    const res = await fetch("/api/status", { cache: "no-store" });
    if (!res.ok) {
      throw new Error("HTTP " + res.status);
    }
    const data = await res.json();
    renderStatus(data);
    statusMsgEl.textContent = "Last update: " + new Date().toLocaleTimeString();
    statusMsgEl.style.color = "#aaaaaa";
  } catch (e) {
    statusMsgEl.textContent = "Error fetching status: " + e.message;
    statusMsgEl.style.color = "#ff5252";
  }
}

function renderStatus(data) {
  serverTimeEl.textContent = data.server_time_iso || "--";

  if (data.weather_talkgroup) {
    weatherTgEl.textContent = data.weather_talkgroup;
    weatherTgEl.style.color = "#4caf50";
  } else {
    weatherTgEl.textContent = "--";
    weatherTgEl.style.color = "#aaaaaa";
  }
  if (data.weather_rx_only) {
    weatherTgEl.textContent += " (RX Only)";
    weatherTgEl.style.color = "#ff5252";
  }

  const entries  = data.entries  || [];
  const bridges  = data.bridges  || [];

  tableBody.innerHTML = "";

  if (entries.length === 0) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 4;
    td.textContent = "No users connected.";
    td.style.textAlign = "center";
    td.style.color = "#777";
    tr.appendChild(td);
    tableBody.appendChild(tr);
  } else {
    for (const e of entries) {
      const tr = document.createElement("tr");
      if (e.speaking) tr.classList.add("speaking");

      const tdUser = document.createElement("td");
      tdUser.textContent = e.callsign || "-";

      const tdTg = document.createElement("td");
      tdTg.textContent = e.talkgroup || "-";

      const tdSpeaking = document.createElement("td");
      const badge = document.createElement("span");
      badge.classList.add("badge", "dot");
      if (e.speaking) {
        badge.classList.add("speaking");
        badge.textContent = "Talking";
      } else {
        badge.classList.add("idle");
        badge.textContent = "Idle";
      }
      tdSpeaking.appendChild(badge);

      const tdDur = document.createElement("td");
      let ms = e.speak_ms || 0;
      if (e.speaking && ms > 0) {
        const sec = ms / 1000;
        if (sec < 60) tdDur.textContent = sec.toFixed(1) + " s";
        else {
          const m = Math.floor(sec / 60);
          const s = Math.floor(sec % 60);
          tdDur.textContent = m + "m " + s + "s";
        }
      } else {
        tdDur.textContent = "-";
      }

      tr.appendChild(tdUser);
      tr.appendChild(tdTg);
      tr.appendChild(tdSpeaking);
      tr.appendChild(tdDur);
      tableBody.appendChild(tr);
    }
  }
}

fetchStatus();
setInterval(fetchStatus, 1000);
